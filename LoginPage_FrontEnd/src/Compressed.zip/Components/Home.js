import React from 'react';

const Home = () => (
  <div>
    <h2>Welcome to the Home Page!</h2>
  </div>
);

export default Home;